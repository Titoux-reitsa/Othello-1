#include <stdbool.h>
#define Lenght_tab 8


// Fonctions de fonctions_bases.c

void Init_tab(char plateau[Lenght_tab][Lenght_tab]);
void Print_tab(char plateau[Lenght_tab][Lenght_tab]); //
bool Is_empty(char plateau[Lenght_tab][Lenght_tab], int ligne, int column); // 

// Fonctions de IA.c